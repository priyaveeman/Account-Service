package com.accounts.Service;

import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;

import com.accounts.Model.Accounts;

public interface AccountsService {
	public Map<String, Integer> getAllAccountHolders();

	public void addAccount(Accounts account);

	public void updateAccount(Accounts accountToBeChanged);

	public void deleteAccount(Long accountNumber);
	
	public Accounts getAccountHolderDetails(long accountNumber);

}
