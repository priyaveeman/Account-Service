package com.accounts.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accounts.Model.Accounts;
import com.accounts.Repository.AccountsRepository;

@Service
public class AccountsServiceImplementation implements AccountsService {

	@Autowired
	AccountsRepository accountsRepository;

	@Override
	public Map<String,Integer> getAllAccountHolders() {
		List<Accounts> list = accountsRepository.findAll();
		Map<String, Integer> map = new HashMap<String, Integer>();
		for(Accounts accounts:list) {
		map.put(accounts.getAccountHolderName(), (int) accounts.getAccountNumber());
		}
		return map;
	}

	@Override
	public void addAccount(Accounts account) {
		accountsRepository.save(account);
	}

	@Override
	public void updateAccount(Accounts accountToBeChanged) {
		accountsRepository.save(accountToBeChanged);
	}

	@Override
	public void deleteAccount(Long accountNumber) {
		accountsRepository.deleteById(accountNumber);
	}

	@Override
	public Accounts getAccountHolderDetails(long accountNumber) {
		/*
		 * List<Accounts> list = accountsRepository.findAll(); list.forEach(x->{
		 * if(x.getAccountNumber()==accountNumber) { return; }
		 * 
		 * }); return null;
		 */
		List<Accounts> list = accountsRepository.findAll(); 
		for (Accounts account:list) {
			if(account.getAccountNumber()==accountNumber) {
				return account;
			}
		}
		return null;
	}

	

	/*
	 * @Override public List<Course> listAllCourse() { List<Course> courseList = new
	 * ArrayList<Course>(); courseRepository.findAll().forEach(value ->
	 * courseList.add(value)); return courseList;
	 * 
	 * }
	 * 
	 * @Override public void deleteCourse(Course course) {
	 * courseRepository.delete(course);
	 * 
	 * }
	 * 
	 * @Override public void updateCourse(Course course) {
	 * courseRepository.save(course);
	 * 
	 * }
	 */

}
