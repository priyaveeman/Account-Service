package com.accounts.Controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.accounts.Model.*;
import com.accounts.Service.AccountsService;

@RestController
@RequestMapping("/accounts")
public class AccountsController {
	//RestTemplate restTemplate=new RestTemplate();
	//String url="http://localhost:8090/employee/findall";
	//Transaction transaction=restTemplate.getForObject(url, Transaction.class);
	
	@Autowired
	AccountsService accountsService;
	
	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/allAccounts")
	public Map<String, Integer> getAllAccountHolder() {
		return accountsService.getAllAccountHolders();
		// map.forEach((key,value)->System.out.println("Account Holder Name: "+key+"
		// Account Number: "+value));
	}

	@GetMapping("/{accountNumber}")
	public Accounts getAccountHolderDetails(@PathVariable("accountNumber") long accountNumber) {
		Accounts account=accountsService.getAccountHolderDetails(accountNumber);
		return account;
	}

	@PostMapping("/addAccount")
	public void addAccount(@RequestBody Accounts accountToBeAdded) {
		accountsService.addAccount(accountToBeAdded);
	}

	@PutMapping("/updateAccount")
	public void updateAccount(@RequestBody Accounts accountToBeChanged) {
		accountsService.updateAccount(accountToBeChanged);
	}

	@DeleteMapping("/deleteAccount/{accountNumber}")
	public void deleteAccount(@PathVariable("accountNumber") Long accountNumber) {
		accountsService.deleteAccount(accountNumber);
	}

	
	
	
	
	/*
	 * @GetMapping("/{id}") public ResponseEntity<EmployeeEntity>
	 * getEmployeeById(@PathVariable("id") Long id) throws RecordNotFoundException {
	 * EmployeeEntity entity = service.getEmployeeById(id);
	 * 
	 * return new ResponseEntity<EmployeeEntity>(entity, new HttpHeaders(),
	 * HttpStatus.OK); }
	 * 
	 * @PostMapping public ResponseEntity<EmployeeEntity>
	 * createOrUpdateEmployee(EmployeeEntity employee) throws
	 * RecordNotFoundException { EmployeeEntity updated =
	 * service.createOrUpdateEmployee(employee); return new
	 * ResponseEntity<EmployeeEntity>(updated, new HttpHeaders(), HttpStatus.OK); }
	 * 
	 * @DeleteMapping("/{id}") public HttpStatus
	 * deleteEmployeeById(@PathVariable("id") Long id) throws
	 * RecordNotFoundException { service.deleteEmployeeById(id); return
	 * HttpStatus.FORBIDDEN; }
	 */

}