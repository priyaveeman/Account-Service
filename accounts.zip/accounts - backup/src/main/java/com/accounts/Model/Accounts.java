package com.accounts.Model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity(name="account")
public class Accounts {
	@Column(name="accountholdername")
	private String accountHolderName;
	@Id
	@Column(name="accountnumber")
	private long accountNumber;
	@Column(name="accounttype")
	private String accountType;
	@Column(name="balance")
	private double balance;
	
}
