DROP TABLE IF EXISTS account;
CREATE table account (
accountnumber INTEGER PRIMARY KEY,
balance FLOAT,
accountholdername VARCHAR(250),
accounttype VARCHAR(250)
);




