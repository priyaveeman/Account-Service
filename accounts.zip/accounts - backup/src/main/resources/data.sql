Insert into account(accountnumber,balance,accountholdername,accounttype) values (1234567890,1000.187988,'name-A','Both Debit and Credit');
Insert into account(accountnumber,balance,accountholdername,accounttype) values (1234567891,1000.187988,'name-B','Both Debit and Credit');
Insert into account(accountnumber,balance,accountholdername,accounttype) values (1234567892,1000.187988,'name-C','Both Debit and Credit');
Insert into account(accountnumber,balance,accountholdername,accounttype) values (1234567893,1000.187988,'name-D','Both Debit and Credit');
Insert into account(accountnumber,balance,accountholdername,accounttype) values (1234567894,1000.187988,'name-E','Both Debit and Credit');

